"""
Ricky Pennepalli
Coding Challenge 1 - Love Is In The Air - Solution
CSE 331 Spring 2020
Professor Sebnem Onsay
"""
from typing import List, Tuple


def story_progression(answers: List[int], questions: List[Tuple[int, int]]) -> List[str]:
    """
    Determine if each tuple in the question list results in a win or a loss for the player.
    It will be a win condition if the chunk contains a majority of 1's. Otherwise, it will be a loss.
    :param answers: list of 0's and 1's, where 1 represents a correct choice, 0 otherwise
    :param questions: list of questions, a list of tuples each of length 2, where
           Element [0] is starting index of a chunk of questions
           Element [1] is ending index of a chunk of questions
    :return: A Python list of the same length as list of questions, where
     each element is either "Win" or "Lose"
    """
    count = 0
    answer_list = []
    final_list = []
    for i in answers:
        count += i
        answer_list.append(count)
    for tup in questions:
        index = tup[1]
        check = (index+1)/2
        if answer_list[index] > check:
            final_list.append("Win")
        else:
            final_list.append("Lose")
    return final_list
