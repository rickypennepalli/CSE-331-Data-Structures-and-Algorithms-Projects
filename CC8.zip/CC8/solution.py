"""
Your Name
Coding Challenge 8
CSE 331 Spring 2021
Professor Sebnem Onsay
"""

from typing import Set, Tuple, Dict
from CC8.InventoryItems import ItemInfo, ALL_ITEMS


class Bundle:
    """ Bundle Class """

    def __init__(self) -> None:
        """
        This function initializes a dictionary in which items and its amount
        can be stored. It also presets the size of the dictionary to 0.0.
        """
        self.bundle = {}
        self.size = 0.0

    def to_set(self) -> Set[Tuple[str, int]]:
        """
        This function iterates through each item in the dictionary and
        returns each item and its amount as tuples in a set.
        """
        answer = set()
        for key, value in self.bundle.items():
            tup = (key, value)
            answer.add(tup)
        return answer

    def add_to_bundle(self, item_name: str, amount: int) -> bool:
        """
        This function takes in an item and its amount and adds them
        to the dictionary and returns True if this is possible.
        It does nothing and returns False otherwise.
        """
        total = ALL_ITEMS[item_name].amount_in_stack
        fraction = amount / total
        if fraction + self.size > 1.0:
            return False
        if item_name not in self.bundle:
            self.bundle[item_name] = amount
        else:
            self.bundle[item_name] += amount
        self.size += fraction
        return True

    def remove_from_bundle(self, item_name: str, amount: int) -> bool:
        """
        This function takes in an item and its amount and removes them
        from the dictionary and returns True if this is possible.
        It does nothing and returns False otherwise.
        """
        if item_name not in self.bundle:
            return False
        total = ALL_ITEMS[item_name].amount_in_stack
        fraction = amount / total
        exists = self.bundle[item_name]
        if fraction > exists / total:
            return False
        new_value = exists - amount
        if new_value == 0:
            del self.bundle[item_name]
            self.size -= fraction
            return True
        self.bundle[item_name] = new_value
        self.size -= fraction
        return True
