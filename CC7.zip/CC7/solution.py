"""
Rithvik Pennepalli
Coding Challenge 7
CSE 331 Spring 2021
Professor Sebnem Onsay
"""
from __future__ import annotations  # allow self-reference
from typing import List, Optional


class TreeNode:
    """Tree Node that contains a value as well as left and right pointers"""
    def __init__(self, val: int, left: TreeNode = None, right: TreeNode = None):
        self.val = val
        self.left = left
        self.right = right


def rewind_combo(points: List[int]) -> List[Optional[int]]:
    """
    This function takes in a list of integers and finds the maximum value
    to the left of an integer in the list that is less than the integer itself.
    It uses its inner functions to create a BST and iterate through it.
    It returns a new list of those values.
    """
    def insert(root, key):
        """
        This inner function takes in a root and a value to be inserted in a BST.
        It creates the BST by inserting each value appropriately and returns nothing.
        """
        if root is None:
            return TreeNode(key)
        if root.val < key:
            root.right = insert(root.right, key)
        elif root.val > key:
            root.left = insert(root.left, key)
        return root

    origin = TreeNode(points[0])
    for i in points:
        insert(origin, i)

    def max_left(root, node, answer=None):
        """
        This function takes in a root, the current node, and the answer (initialized
        to None). It iterates through the BST and returns the maximum value to the
        left of an integer in the list that is less than the integer itself.
        """
        if root.val < node:
            return max_left(root.right, node, root.val)
        if root.val > node:
            return max_left(root.left, node, answer)
        return answer

    output = []
    for i in points:
        answer = max_left(origin, i)
        output.append(answer)
    return output
