"""
Rithvik Pennepalli
Coding Challenge 5
CSE 331 Spring 2021
Professor Sebnem Onsay
"""
from typing import List
import sys
sys.setrecursionlimit(3000)


def check_walls_cover(walls: List[int]) -> List[int]:
    """
    This function takes in a list of integers as wall heights and returns a list
    of how many walls can be seen at each index. It uses two helper functions that
    iterate through the left and right side of the list respectively.
    """
    def right_walls(index, temp, right_iter, count):
        """
        This function takes the indexes of the current wall, the next wall to the right,
        and a count. It also takes in a temporary variable at which the index of the
        current tallest wall is stored; it is defaulted to the current initial wall index.
        It recursively returns the final count of the number of walls that can be seen
        from the current wall.
        """
        if right_iter == len(walls):
            return count
        if walls[right_iter] > walls[index] and walls[right_iter] > walls[temp]:
            count += 1
            temp = right_iter
        right_iter += 1
        return right_walls(index, temp, right_iter, count)

    def left_walls(index, temp, left_iter, count):
        """
        This function takes the indexes of the current wall, the next wall to the left,
        and a count. It also takes in a temporary variable at which the index of the
        current tallest wall is stored; it is defaulted to the current initial wall index.
        It recursively returns the final count of the number of walls that can be seen
        from the current wall.
        """
        if left_iter < 0:
            return count
        if walls[left_iter] > walls[index] and walls[left_iter] > walls[temp]:
            count += 1
            temp = left_iter
        left_iter -= 1
        return left_walls(index, temp, left_iter, count)

    answer = []
    for i in range(len(walls)):
        answer.append(right_walls(i, i, i + 1, 0) + left_walls(i, i, i - 1, 0))
    return answer
