"""
Name: Rithvik Pennepalli
Project 3 - Hybrid Sorting
Developed by Sean Nguyen and Andrew Haas
Based on work by Zosha Korzecke and Olivia Mikola
CSE 331 Spring 2021
Professor Sebnem Onsay
"""
from typing import TypeVar, List, Callable
import copy

T = TypeVar("T")            # represents generic type


def merge_sort(data: List[T], threshold: int = 0,
               comparator: Callable[[T, T], bool] = lambda x, y: x <= y) -> int:
    """
    This function takes in a list of values to be sorted through merging and a threshold value,
    at which the function calls an insertion sort. It also takes in a comparator function which returns
    true if the first value is less than or equal the second value. It uses its inner function
    and recursively sorts the list and returns the inversion count.
    """
    def merge(left_side, right_side, main_list, count):
        """
        This inner function takes two sub lists of the data and sorts the elements according to
        the comparator given. It also accumulates a count of the inversions and returns it.
        """
        i = 0
        j = 0
        while i + j < len(main_list):
            if j == len(right_side) or (i < len(left_side) and comparator(left_side[i], right_side[j])):
                main_list[i + j] = left_side[i]
                i += 1
            else:
                main_list[i + j] = right_side[j]
                j += 1
                count += len(left_side) - i
        return count

    if len(data) <= 1:
        return 0
    elif len(data) < threshold:
        insertion_sort(data, comparator)
        return 0
    middle = len(data) // 2
    left = data[:middle]
    right = data[middle:]
    final_count = 0
    final_count += merge_sort(left, threshold, comparator)
    final_count += merge_sort(right, threshold, comparator)
    return merge(left, right, data, final_count)


def insertion_sort(data: List[T], comparator: Callable[[T, T], bool] = lambda x, y: x <= y) -> None:
    """
    This function takes in a list of values to be sorted through insertion. It also takes in a
    comparator function which returns true if the first value is less than or equal the second
    value. It sorts the list and returns nothing.
    """
    for i in range(1, len(data)):
        count = i
        while count > 0 and comparator(data[count], data[count - 1]):
            temp = data[count]
            data[count] = data[count - 1]
            data[count - 1] = temp
            count -= 1


def hybrid_sort(data: List[T], threshold: int,
                comparator: Callable[[T, T], bool] = lambda x, y: x <= y) -> None:
    """
    This function takes in a list of values to be sorted through merging, a threshold value,
    and a comparator function. It merely calls the merge sort function with the given parameters
    and returns nothing.
    """
    merge_sort(data, threshold, comparator)


def inversions_count(data: List[T]) -> int:
    """
    This function takes in a list of values and creates a copy of the list in order to
    find an inversion count. It does this via the merge sort function and returns the count.
    """
    copy_data = copy.deepcopy(data)
    return merge_sort(copy_data, comparator=lambda x, y: x <= y)


def reverse_sort(data: List[T], threshold: int) -> None:
    """
    This function takes in a list of values and a threshold value. It uses the merge sort
    function to sort the elements in reverse order. It returns nothing.
    """
    merge_sort(data, threshold, comparator=lambda x, y: x >= y)


def password_rate(password: str) -> float:
    """
    This function takes in a string and calculates a rating for the string based on a formula.
    It returns that rating as a float.
    """
    length = len(password) ** 0.5
    unique = len(set(password)) ** 0.5
    password_list = []
    for i in password:
        password_list.append(i)
    inv = inversions_count(password_list)
    return float(length * unique + inv)


def password_sort(data: List[str]) -> None:
    """
    This function takes in a list of values and sorts them based on the rating of each element.
    It uses loops and previous functions to do so. It returns nothing.
    """
    sort_list = []
    for i in data:
        rate = password_rate(i)
        tup = (rate, i)
        sort_list.append(tup)
    merge_sort(sort_list, comparator=lambda x, y: x[0] >= y[0])

    for i in range(len(sort_list)):
        data[i] = sort_list[i][1]