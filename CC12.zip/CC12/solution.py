"""
Rithvik Pennepalli
CC12 - Dynamic Programming
CSE 331 Spring 2021
Professor Sebnem Onsay
"""

from typing import List


def colonel_concat(dialogue: List[str]) -> int:
    """
    This function takes in a list of strings and uses its inner
    function to concatenate it.
    It returns the minimum number of copies to concatenate the string.
    """

    def concat(main_list, start, end):
        """
        This function takes in the start and end indexes of the list
        and recursively merges the two strings. It returns the minimum
        number of copies to concatenate.
        """
        if start == end:
            return 0

        if inf[start][end] == float("inf"):
            num = float("inf")
            count = 0
            for i in range(start, end + 1):
                count += words[i]
            for j in range(start, end):
                first = count + concat(main_list, start, j) + concat(main_list, j + 1, end)
                num = min(num, first)
                inf[start][end] = num

            return num
        return inf[start][end]

    inf = []
    words = []
    for i in range(len(dialogue)):
        temp = []
        words.append(len(dialogue[i]))
        for x in range(len(dialogue)):
            temp.append(float("inf"))
        inf.append(temp)

    return concat(inf, 0, len(dialogue) - 1)






















