"""
Project 1
CSE 331 S21 (Onsay)
Ricky Pennepalli
DLL.py
"""

from typing import TypeVar, List, Tuple
import datetime

# for more information on typehinting, check out https://docs.python.org/3/library/typing.html
T = TypeVar("T")            # represents generic type
Node = TypeVar("Node")      # represents a Node object (forward-declare to use in Node __init__)

# pro tip: PyCharm auto-renders docstrings (the multiline strings under each function definition)
# in its "Documentation" view when written in the format we use here. Open the "Documentation"
# view to quickly see what a function does by placing your cursor on it and using CTRL + Q.
# https://www.jetbrains.com/help/pycharm/documentation-tool-window.html


class Node:
    """
    Implementation of a doubly linked list node.
    Do not modify.
    """
    __slots__ = ["value", "next", "prev"]

    def __init__(self, value: T, next: Node = None, prev: Node = None) -> None:
        """
        Construct a doubly linked list node.

        :param value: value held by the Node.
        :param next: reference to the next Node in the linked list.
        :param prev: reference to the previous Node in the linked list.
        :return: None.
        """
        self.next = next
        self.prev = prev
        self.value = value

    def __repr__(self) -> str:
        """
        Represents the Node as a string.

        :return: string representation of the Node.
        """
        return str(self.value)

    def __str__(self) -> str:
        """
        Represents the Node as a string.

        :return: string representation of the Node.
        """
        return str(self.value)


class DLL:
    """
    Implementation of a doubly linked list without padding nodes.
    Modify only below indicated line.
    """
    __slots__ = ["head", "tail", "size"]

    def __init__(self) -> None:
        """
        Construct an empty doubly linked list.

        :return: None.
        """
        self.head = self.tail = None
        self.size = 0

    def __repr__(self) -> str:
        """
        Represent the DLL as a string.

        :return: string representation of the DLL.
        """
        result = ""
        node = self.head
        while node is not None:
            result += str(node)
            if node.next is not None:
                result += " <-> "
            node = node.next
        return result

    def __str__(self) -> str:
        """
        Represent the DLL as a string.

        :return: string representation of the DLL.
        """
        return repr(self)

    # MODIFY BELOW #

    def empty(self) -> bool:
        """
        Return boolean indicating whether DLL is empty.

        Suggested time & space complexity (respectively): O(1) & O(1).

        :return: True if DLL is empty, else False.
        """
        if self.size == 0:
            return True
        return False

    def push(self, val: T, back: bool = True) -> None:
        """
        Create Node containing `val` and add to back (or front) of DLL. Increment size by one.

        Suggested time & space complexity (respectively): O(1) & O(1).

        :param val: value to be added to the DLL.
        :param back: if True, add Node containing value to back (tail-end) of DLL;
            if False, add to front (head-end).
        :return: None.
        """
        new_node = Node(val)

        if self.size == 0:
            self.head = new_node
            self.tail = new_node
        elif back:
            new_node.prev = self.tail
            self.tail.next = new_node
            self.tail = new_node
        else:
            new_node.next = self.head
            self.head.prev = new_node
            self.head = new_node

        self.size += 1

    def pop(self, back: bool = True) -> None:
        """
        Remove Node from back (or front) of DLL. Decrement size by 1. If DLL is empty, do nothing.

        Suggested time & space complexity (respectively): O(1) & O(1).

        :param back: if True, remove Node from (tail-end) of DLL;
            if False, remove from front (head-end).
        :return: None.
        """

        if self.size == 0:
            return None
        elif self.size == 1:
            self.head = None
            self.tail = None
        elif back:
            cur_node = self.tail
            cur_node.prev.next = None
            self.tail = cur_node.prev
        else:
            cur_node = self.head
            cur_node.next.prev = None
            self.head = cur_node.next

        self.size -= 1

    def from_list(self, source: List[T]) -> None:
        """
        Construct DLL from a standard Python list.

        Suggested time & space complexity (respectively): O(n) & O(n).

        :param source: standard Python list from which to construct DLL.
        :return: None.
        """

        if len(source) > 0:
            first_value = source[0]
            first_node = Node(first_value)
            self.head = first_node
            self.tail = first_node
            self.size += 1
            for elem in source[1:]:
                temp_node = Node(elem)
                temp_node.prev = self.tail
                self.tail.next = temp_node
                self.tail = temp_node
                self.size += 1
        else:
            self.head = None
            self.tail = None

    def to_list(self) -> List[T]:
        """
        Construct standard Python list from DLL.

        Suggested time & space complexity (respectively): O(n) & O(n).

        :return: standard Python list containing values stored in DLL.
        """
        dll_list = []

        if self.size == 0:
            return dll_list
        else:
            first_node = self.head
            first_value = first_node.value
            dll_list.append(first_value)
            next_node = first_node.next

            for i in range(self.size-1):
                data = next_node.value
                dll_list.append(data)
                next_node = next_node.next
            return dll_list

    def find(self, val: T) -> Node:
        """
        Find first instance of `val` in the DLL and return associated Node object.

        Suggested time & space complexity (respectively): O(n) & O(1).

        :param val: value to be found in DLL.
        :return: first Node object in DLL containing `val`.
            If `val` does not exist in DLL, return None.
        """

        if self.size == 0:
            return None

        first_node = self.head
        first_value = first_node.value
        if first_value == val:
            return first_node
        else:
            next_node = first_node.next

            for i in range(self.size - 1):
                data = next_node.value
                if data == val:
                    return next_node
                else:
                    next_node = next_node.next
            return None

    def find_all(self, val: T) -> List[Node]:
        """
        Find all instances of `val` in DLL and return Node objects in standard Python list.

        Suggested time & space complexity (respectively): O(n) & O(n).

        :param val: value to be searched for in DLL.
        :return: Python list of all Node objects in DLL containing `val`.
            If `val` does not exist in DLL, return empty list.
        """
        value_list = []
        if self.size == 0:
            return value_list

        first_node = self.head
        first_value = first_node.value
        if first_value == val:
            value_list.append(first_node)
        next_node = first_node.next

        for i in range(self.size - 1):
            data = next_node.value
            if data == val:
                value_list.append(next_node)
            next_node = next_node.next
        return value_list

    def delete(self, val: T) -> bool:
        """
        Delete first instance of `val` in the DLL.

        Suggested time & space complexity (respectively): O(n) & O(1).

        :param val: value to be deleted from DLL.
        :return: True if Node containing `val` was deleted from DLL; else, False.
        """
        if self.size == 0:
            return False
        if self.size == 1:
            node = self.head
            if node.value == val:
                self.head = None
                self.tail = None
                self.size -= 1
                return True
            else:
                return False
        else:
            node = self.head
            for i in range(self.size):
                if node.value == val:
                    if node.next is None:  # tail
                        node.prev.next = None
                        self.tail = node.prev
                        self.size -= 1
                        return True
                    elif node.prev is None:  # head
                        node.next.prev = None
                        self.head = node.next
                        self.size -= 1
                        return True
                    else:  # middle
                        pred_node = node.prev
                        suc_node = node.next
                        pred_node.next = suc_node
                        suc_node.prev = pred_node
                        self.size -= 1
                        return True
                node = node.next
            return False

    def delete_all(self, val: T) -> int:
        """
        Delete all instances of `val` in the DLL.

        Suggested time & space complexity (respectively): O(n) & O(1).

        :param val: value to be deleted from DLL.
        :return: integer indicating the number of Nodes containing `val` deleted from DLL;
                 if no Node containing `val` exists in DLL, return 0.
        """
        if self.size == 0:
            return 0
        if self.size == 1:
            node = self.head
            if node.value == val:
                self.head = None
                self.tail = None
                self.size -= 1
                return 1
            return 0
        count = 0
        node = self.head
        while node is not None:
            if node.value == val:
                count += 1
                if self.size == 1:
                    self.head = None
                    self.tail = None
                    self.size -= 1
                    return count
                elif node.next is None:  # tail
                    node.prev.next = None
                    self.tail = node.prev
                    self.size -= 1
                    return count
                elif node.prev is None:  # head
                    node.next.prev = None
                    self.head = node.next
                else:  # middle
                    pred_node = node.prev
                    suc_node = node.next
                    pred_node.next = suc_node
                    suc_node.prev = pred_node
                self.size -= 1
            node = node.next
        return count

    def reverse(self) -> None:
        """
        Reverse DLL in-place by modifying all `next` and `prev` references of Nodes in the
        DLL and resetting the `head` and `tail` references.
        Must be implemented in-place for full credit. May not create new Node objects.

        Suggested time & space complexity (respectively): O(n) & O(1).

        :return: None.
        """
        head = self.head
        while head is not None:
            second = head.next
            head.next = head.prev  # switch next and prev
            head.prev = second
            head = head.prev

        # switch head and tail
        head = self.head
        self.head = self.tail
        self.tail = head
        return None


class Stock:
    """
    Implementation of a stock price on a given day.
    Do not modify.
    """

    __slots__ = ["date", "price"]

    def __init__(self, date: datetime.date, price: float) -> None:
        """
        Construct a stock.

        :param date: date of stock.
        :param price: the price of the stock at the given date.
        """
        self.date = date
        self.price = price

    def __repr__(self) -> str:
        """
        Represents the Stock as a string.

        :return: string representation of the Stock.
        """
        return f"<{str(self.date)}, ${self.price}>"

    def __str__(self) -> str:
        """
        Represents the Stock as a string.

        :return: string representation of the Stock.
        """
        return repr(self)


def intellivest(stocks: DLL) -> Tuple[datetime.date, datetime.date, float]:
    """
    Given a DLL representing daily stock prices,
    find the optimal streak of days over which to invest.
    To be optimal, the streak of stock prices must:

        (1) Be strictly increasing, such that the price of the stock on day i+1
        is greater than the price of the stock on day i, and
        (2) Have the greatest total increase in stock price from
        the first day of the streak to the last.

    In other words, the optimal streak of days over which to invest is the one over which stock
    price increases by the greatest amount, without ever going down (or staying constant).

    Suggested time & space complexity (respectively): O(n) & O(1).

    :param stocks: DLL with Stock objects as node values, as defined above.
    :return: Tuple with the following elements:
        [0]: date: The date at which the optimal streak begins.
        [1]: date: The date at which the optimal streak ends.
        [2]: float: The (positive) change in stock price between the start and end
                dates of the streak.
    """

    if stocks.size == 0:
        return (None, None, 0.0)
    elif stocks.size == 1:
        node = stocks.head
        return (node.value.date, node.value.date, 0.0)
    else:
        node = stocks.head
        final_price = 0
        final_start_date = node.value.date
        final_end_date = node.value.date
        temp_price = 0
        temp_end_date = node.value.date
        temp_start_date = node.value.date

        while node is not None:
            if node.next is None:  # check if it is at tail
                if temp_price > final_price:
                    final_end_date = temp_end_date
                    final_price = temp_price
                    final_start_date = temp_start_date
                return (final_start_date, final_end_date, final_price)
            else:
                cur_price = node.value.price  # i
                next_price = node.next.value.price  # j
                diff = next_price-cur_price

            if diff > 0:
                temp_price += diff
                temp_end_date = node.next.value.date  # change j
            elif diff < 0:
                if temp_price > final_price:
                    final_end_date = temp_end_date
                    final_price = temp_price
                    final_start_date = temp_start_date
                temp_price = 0
                temp_start_date = node.next.value.date  # change i
            else:
                node = node.next
                continue
            node = node.next

        return (final_start_date, final_end_date, final_price)
