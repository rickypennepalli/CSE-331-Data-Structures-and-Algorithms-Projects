"""
Your Name Here
Project 5 - PriorityHeaps - Solution Code
CSE 331 Fall 2020
Dr. Sebnem Onsay
"""

from typing import List, Any
from Project7.PriorityNode import PriorityNode, MaxNode, MinNode
# from PriorityNode import PriorityNode, MaxNode, MinNode


class PriorityQueue:
    """
    Implementation of a priority queue - the highest/lowest priority elements
    are at the front (root). Can act as a min or max-heap.
    """

    #   ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #   DO NOT MODIFY the following attributes/functions
    #   Modify only below indicated line
    __slots__ = ["_data", "_is_min"]

    def __init__(self, is_min: bool = True):
        """
        Constructs the priority queue
        :param is_min: If the priority queue acts as a priority min or max-heap.
        """
        self._data = []
        self._is_min = is_min

    def __str__(self) -> str:
        """
        Represents the priority queue as a string
        :return: string representation of the heap
        """
        return F"PriorityQueue [{', '.join(str(item) for item in self._data)}]"

    __repr__ = __str__

    def to_tree_str(self) -> str:
        """
        Generates string representation of heap in Breadth First Ordering Format
        :return: String to print
        """
        string = ""

        # level spacing - init
        nodes_on_level = 0
        level_limit = 1
        spaces = 10 * int(1 + len(self))

        for i in range(len(self)):
            space = spaces // level_limit
            # determine spacing

            # add node to str and add spacing
            string += str(self._data[i]).center(space, ' ')

            # check if moving to next level
            nodes_on_level += 1
            if nodes_on_level == level_limit:
                string += '\n'
                level_limit *= 2
                nodes_on_level = 0
            i += 1

        return string

    def is_min_heap(self) -> bool:
        """
        Check if priority queue is a min or a max-heap
        :return: True if min-heap, False if max-heap
        """
        return self._is_min

    #   ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #   Modify below this line
    def __len__(self) -> int:
        """
        This function finds the length of a priority queue
        :return: the length as an integer
        """
        return len(self._data)

    def empty(self) -> bool:
        """
        This function finds if the priority queue is empty
        :return: bool indicating whether the queue is empty
        """
        return len(self._data) == 0

    def peek(self) -> PriorityNode:
        """
        This function finds the first node in the queue, or the highest priority
        :return: the first node if found, none otherwise
        """
        if len(self._data) == 0:
            return None
        return self._data[0]

    def get_left_child_index(self, index: int) -> int:
        """
        This function finds the index of the left child in the priority queue
        :param index: index of the parent node
        :return: index of the left child
        """
        index = 2 * index + 1
        if index >= len(self):
            return None
        return index

    def get_right_child_index(self, index: int) -> int:
        """
        This function finds the index of the right child in the priority queue
        :param index: index of the parent node
        :return: index of the right child
        """
        index = 2 * index + 2
        if index >= len(self._data):
            return None
        return index

    def get_parent_index(self, index: int) -> int:
        """
        This function finds the index of the parent node in the priority queue
        :param index: index of a child node
        :return: index of the parent node
        """
        index = (index-1) // 2
        if 0 <= index <= len(self._data):
            return index
        return None

    def push(self, priority: Any, val: Any) -> None:
        """
        This function appends a new node into the priority queue based on its priority
        :param priority: priority of the node
        :param val: value of the node
        :return: None
        """
        if self.is_min_heap():
            node = MinNode(priority, val)
            self._data.append(node)
            size = len(self._data) - 1
            self.percolate_up(size)
        else:
            node = MaxNode(priority, val)
            self._data.append(node)
            size = len(self._data) - 1
            self.percolate_up(size)

    def pop(self) -> PriorityNode:
        """
        This function removes the top priority node from the queue
        :return: MinNode or MaxNode being removed
        """
        if not self.empty():
            size = len(self._data) - 1
            self._data[0], self._data[size] = self._data[size], self._data[0]
            item = self._data.pop()  # and remove it from the list;
            self.percolate_down(0)  # then fix new root
            return item

    def get_minmax_child_index(self, index: int) -> int:
        """
        This function finds the min or max child depending on the type of heap
        :param index: index of parent node
        :return: index of min or max child if found, None otherwise
        """
        if not self.empty():
            left = self.get_left_child_index(index)
            right = self.get_right_child_index(index)
            if left is None:
                return right
            if right is None:
                return left
            if self._data[left] < self._data[right]:
                return left
            return right

    def percolate_up(self, index: int) -> None:
        """
        This function moves a node in the queue up to its correct position
        :param index: index of the node to be moved
        :return: None
        """
        parent = self.get_parent_index(index)
        if index > 0 and self._data[index] < self._data[parent]:
            self._data[index], self._data[parent] = self._data[parent], self._data[index]
            self.percolate_up(parent)  # recur at position of parent

    def percolate_down(self, index: int) -> None:
        """
        This function moves a node in the queue down to its correct position
        :param index: index of the node to be moved
        :return: None
        """
        left = self.get_left_child_index(index)
        right = self.get_right_child_index(index)
        if left is not None:
            child = left  # although right may be smaller
            if right is not None:
                if self._data[right] < self._data[left]:
                    child = right
            if self._data[child] < self._data[index]:
                self._data[index], self._data[child] = self._data[child], self._data[index]
                self.percolate_down(child)


class MaxHeap:
    """
    Implementation of a max-heap - the highest value is at the front (root).

    Initializes a PriorityQueue with is_min set to False.

    Uses the priority queue to satisfy the min heap properties by initializing
    the priority queue as a max-heap, and then using value as both the priority
    and value.
    """

    #   ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #   DO NOT MODIFY the following attributes/functions
    #   Modify only below indicated line

    __slots__ = ['_pqueue']

    def __init__(self):
        """
        Constructs a priority queue as a max-heap
        """
        self._pqueue = PriorityQueue(False)

    def __str__(self) -> str:
        """
        Represents the max-heap as a string
        :return: string representation of the heap
        """
        # NOTE: This hides implementation details
        return F"MaxHeap [{', '.join(item.value for item in self._pqueue._data)}]"

    __repr__ = __str__

    def to_tree_str(self) -> str:
        """
        Generates string representation of heap in Breadth First Ordering Format
        :return: String to print
        """
        return self._pqueue.to_tree_str()

    def __len__(self) -> int:
        """
        Determine the amount of nodes on the heap
        :return: Length of the data inside the heap
        """
        return len(self._pqueue)

    def empty(self) -> bool:
        """
        Checks if the heap is empty
        :returns: True if empty, else False
        """
        return self._pqueue.empty()

    #   ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #   Modify below this line
    def peek(self) -> Any:
        """
        This function finds the max value of the queue or the root node
        :return: root node if found, None otherwise
        """
        if not self.empty():
            data = self._pqueue._data[0]
            return data.value

    def push(self, val: Any) -> None:
        """
        This function inserts a node into the heap with the specified value
        :param val: value of the node to be inserted
        :return: None
        """
        self._pqueue.push(val, val)

    def pop(self) -> Any:
        """
        This function removes the max node from the heap
        :return: The value of the max node being removed
        """
        if not self.empty():
            return self._pqueue.pop().value


class MinHeap(MaxHeap):
    """
    Implementation of a max-heap - the highest value is at the front (root).

    Initializes a PriorityQueue with is_min set to True.

    Inherits from MaxHeap because it uses the same exact functions, but instead
    has a priority queue with a min-heap.
    """

    #   ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #   DO NOT MODIFY the following attributes/functions
    __slots__ = []

    def __init__(self):
        """
        Constructs a priority queue as a min-heap
        """
        super().__init__()
        self._pqueue._is_min = True


def heap_sort(array: List[Any]) -> None:
    """
    This function sorts the array using heap sort through a max heap
    :param array: list to be sorted
    :return: None
    """
    def create_heap(arr, size, index):
        """
        This function creates a heap to be sorted based on the respective indexes
        :param array: list to be sorted, size of the list, current index
        :return: None
        """
        largest = index
        left = 2 * index + 1
        right = 2 * index + 2

        if left < size and arr[largest] < arr[left]:
            largest = left
        if right < size and arr[largest] < arr[right]:
            largest = right
        if largest != index:
            arr[index], arr[largest] = arr[largest], arr[index]
            create_heap(arr, size, largest)

    size = len(array)
    for i in range(size // 2 - 1, -1, -1):
        create_heap(array, size, i)

    for i in range(size - 1, 0, -1):
        array[i], array[0] = array[0], array[i]
        create_heap(array, i, 0)


def current_medians(array: List[int]) -> List[int]:
    """
    This function accumulates a list of medians based on each integer in a list
    :param array: list of integers
    :return: list of medians based on each integer in the list
    """
    pq = PriorityQueue()
    for index, num in enumerate(array):
        pq.push(index, num)
    sorted_array = []
    new_list = []
    if not pq.empty():
        first = pq.pop()
        new_list.append(first.value)
        sorted_array.append(first.value)
        for i in range(1, len(array)):
            x = pq.pop()
            value = x.value
            size = len(new_list)
            sorted_array.append(value)
            sorted_array.sort()
            if size % 2 == 0:  # even
                index = int(size // 2)
                old = int(sorted_array[index])
                new_list.append(old)
            else:  # odd
                index = int(size // 2)
                value1 = sorted_array[index]
                value2 = sorted_array[index + 1]
                median = (value1 + value2) / 2
                median = round(median, 1)
                new_list.append(median)

    return new_list
