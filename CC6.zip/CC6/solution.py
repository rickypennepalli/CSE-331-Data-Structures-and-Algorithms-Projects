"""
Name: Rithvik Pennepalli
Coding Challenge 6
CSE 331 Spring 2021
Professor Sebnem Onsay
"""
import queue


def gates_needed(departures, arrivals):
    """
    This function takes in two lists of floats: departure times and arrival
    times. It iterates through each list and creates a queue of the gates
    being used in the airport. It returns the maximum number of gates used
    at one time.
    """
    airport = queue.Queue()
    arrival_iterator = 0
    departure_iterator = 0
    gates = airport.qsize()
    final = gates
    while departure_iterator != len(departures) and arrival_iterator != len(arrivals):
        if departures[departure_iterator] < arrivals[arrival_iterator]:
            airport.get()
            departure_iterator += 1
        elif departures[departure_iterator] == arrivals[arrival_iterator]:
            departure_iterator += 1
            arrival_iterator += 1
        else:
            airport.put(arrivals[arrival_iterator])
            arrival_iterator += 1
        gates = airport.qsize()
        if gates >= final:
            final = gates

    while arrival_iterator != len(arrivals):
        airport.put(arrivals[arrival_iterator])
        arrival_iterator += 1
    gates = airport.qsize()
    if gates >= final:
        final = gates

    return final
