"""
Project 5
CSE 331 S21 (Onsay)
Your Name
AVLTree.py
"""

import queue
from typing import TypeVar, Generator, List, Tuple

# for more information on typehinting, check out https://docs.python.org/3/library/typing.html
T = TypeVar("T")            # represents generic type
Node = TypeVar("Node")      # represents a Node object (forward-declare to use in Node __init__)
AVLWrappedDictionary = TypeVar("AVLWrappedDictionary")


####################################################################################################


class Node:
    """
    Implementation of an AVL tree node.
    Do not modify.
    """
    # preallocate storage: see https://stackoverflow.com/questions/472000/usage-of-slots
    __slots__ = ["value", "parent", "left", "right", "height"]

    def __init__(self, value: T, parent: Node = None,
                 left: Node = None, right: Node = None) -> None:
        """
        Construct an AVL tree node.

        :param value: value held by the node object
        :param parent: ref to parent node of which this node is a child
        :param left: ref to left child node of this node
        :param right: ref to right child node of this node
        """
        self.value = value
        self.parent, self.left, self.right = parent, left, right
        self.height = 0

    def __repr__(self) -> str:
        """
        Represent the AVL tree node as a string.

        :return: string representation of the node.
        """
        return f"<{str(self.value)}>"

    def __str__(self) -> str:
        """
        Represent the AVL tree node as a string.

        :return: string representation of the node.
        """
        return f"<{str(self.value)}>"


####################################################################################################


class AVLTree:
    """
    Implementation of an AVL tree.
    Modify only below indicated line.
    """
    # preallocate storage: see https://stackoverflow.com/questions/472000/usage-of-slots
    __slots__ = ["origin", "size"]

    def __init__(self) -> None:
        """
        Construct an empty AVL tree.
        """
        self.origin = None
        self.size = 0

    def __repr__(self) -> str:
        """
        Represent the AVL tree as a string. Inspired by Anna De Biasi (Fall'20 Lead TA).

        :return: string representation of the AVL tree
        """
        if self.origin is None:
            return "Empty AVL Tree"

        # initialize helpers for tree traversal
        root = self.origin
        result = ""
        q = queue.SimpleQueue()
        levels = {}
        q.put((root, 0, root.parent))
        for i in range(self.origin.height + 1):
            levels[i] = []

        # traverse tree to get node representations
        while not q.empty():
            node, level, parent = q.get()
            if level > self.origin.height:
                break
            levels[level].append((node, level, parent))

            if node is None:
                q.put((None, level + 1, None))
                q.put((None, level + 1, None))
                continue

            if node.left:
                q.put((node.left, level + 1, node))
            else:
                q.put((None, level + 1, None))

            if node.right:
                q.put((node.right, level + 1, node))
            else:
                q.put((None, level + 1, None))

        # construct tree using traversal
        spaces = pow(2, self.origin.height) * 12
        result += "\n"
        result += f"AVL Tree: size = {self.size}, height = {self.origin.height}".center(spaces)
        result += "\n\n"
        for i in range(self.origin.height + 1):
            result += f"Level {i}: "
            for node, level, parent in levels[i]:
                level = pow(2, i)
                space = int(round(spaces / level))
                if node is None:
                    result += " " * space
                    continue
                if not isinstance(self.origin.value, AVLWrappedDictionary):
                    result += f"{node} ({parent} {node.height})".center(space, " ")
                else:
                    result += f"{node}".center(space, " ")
            result += "\n"
        return result

    def __str__(self) -> str:
        """
        Represent the AVL tree as a string. Inspired by Anna De Biasi (Fall'20 Lead TA).

        :return: string representation of the AVL tree
        """
        return repr(self)

    def height(self, root: Node) -> int:
        """
        Return height of a subtree in the AVL tree, properly handling the case of root = None.
        Recall that the height of an empty subtree is -1.

        :param root: root node of subtree to be measured
        :return: height of subtree rooted at `root` parameter
        """
        return root.height if root is not None else -1

    def left_rotate(self, root: Node) -> Node:
        """
        Perform a left rotation on the subtree rooted at `root`. Return new subtree root.

        :param root: root node of unbalanced subtree to be rotated.
        :return: new root node of subtree following rotation.
        """
        if root is None:
            return None

        # pull right child up and shift right-left child across tree, update parent
        new_root, rl_child = root.right, root.right.left
        root.right = rl_child
        if rl_child is not None:
            rl_child.parent = root

        # right child has been pulled up to new root -> push old root down left, update parent
        new_root.left = root
        new_root.parent = root.parent
        if root.parent is not None:
            if root is root.parent.left:
                root.parent.left = new_root
            else:
                root.parent.right = new_root
        root.parent = new_root

        # handle tree origin case
        if root is self.origin:
            self.origin = new_root

        # update heights and return new root of subtree
        root.height = 1 + max(self.height(root.left), self.height(root.right))
        new_root.height = 1 + max(self.height(new_root.left), self.height(new_root.right))
        return new_root

    ########################################
    # Implement functions below this line. #
    ########################################

    def right_rotate(self, root: Node) -> Node:
        """
        This function takes in a root node and rotates the tree to the right in order to
        balance it. It updates the height of the tree and returns the new root.
        """
        if root is None:
            return None

        # pull right child up and shift right-left child across tree, update parent
        new_root, lr_child = root.left, root.left.right
        root.left = lr_child
        if lr_child is not None:
            lr_child.parent = root

        # right child has been pulled up to new root -> push old root down left, update parent
        new_root.right = root
        new_root.parent = root.parent
        if root.parent is not None:
            if root is root.parent.right:
                root.parent.right = new_root
            else:
                root.parent.left = new_root
        root.parent = new_root

        # handle tree origin case
        if root is self.origin:
            self.origin = new_root

        # update heights and return new root of subtree
        root.height = 1 + max(self.height(root.left), self.height(root.right))
        new_root.height = 1 + max(self.height(new_root.left), self.height(new_root.right))
        return new_root

    def balance_factor(self, root: Node) -> int:
        """
        This function takes in a root node and calculates the balance factor of it by accessing
        its left and right heights. It returns the balance factor as an integer.
        """
        if root is None:
            return 0
        left_node = root.left
        right_node = root.right
        if left_node is None:
            left_height = -1
        else:
            left_height = left_node.height
        if right_node is None:
            right_height = -1
        else:
            right_height = right_node.height

        balance = left_height - right_height
        return balance

    def rebalance(self, root: Node) -> Node:
        """
        This function takes in a root node and recursively re-balances the tree by using
        the left and right rotate functions and the balance factor function.
        It returns the new root.
        """
        if self.balance_factor(root) == 2:  # left heavy
            if self.balance_factor(root.left) < 0:  # L-R
                root.left = self.left_rotate(root.left)
                return self.right_rotate(root)
            return self.right_rotate(root)
        if self.balance_factor(root) == -2:  # right heavy
            if self.balance_factor(root.right) > 0:  # R-L
                root.right = self.right_rotate(root.right)
                return self.left_rotate(root)
            return self.left_rotate(root)
        return root  # no need to re-balance

    def insert(self, root: Node, val: T) -> Node:
        """
        This function takes in a root node and a value and inserts a new node containing
        that value into the tree. It updates the height, size, and origin as well as
        re-balances the tree using the re-balance function.
        """
        if self.origin is None:
            self.origin = Node(val)
            self.size += 1
            self.origin.height = max(self.height(self.origin.left), self.height(self.origin.right)) + 1
            return self.origin

        if val < root.value:
            if root.left is None:
                root.left = Node(val)
                root.left.parent = root
                self.size += 1
            else:
                root.left = self.insert(root.left, val)
        elif val > root.value:
            if root.right is None:
                root.right = Node(val)
                root.right.parent = root
                self.size += 1
            else:
                root.right = self.insert(root.right, val)

        root.height = max(self.height(root.left), self.height(root.right)) + 1
        return self.rebalance(root)  # recursively re-balance the tree

    def min(self, root: Node) -> Node:
        """
        This function takes in a root node and uses its left children to
        recursively find and return the minimum value of the tree.
        """
        if root is None:
            return None
        if root.left is not None:
            return self.min(root.left)
        return root

    def max(self, root: Node) -> Node:
        """
        This function takes in a root node and uses its right children to
        recursively find and return the maximum value of the tree.
        """
        if root is None:
            return None
        if root.right is not None:
            return self.max(root.right)
        return root

    def search(self, root: Node, val: T) -> Node:
        """
        This function takes in a root node and a value. It uses its children to
        recursively search for the value in the tree. If found, it returns the node.
        Else, it returns the node below at which the value should be inserted.
        """
        if root is None:
            return None
        if root.value == val:
            return root
        if root.left is not None and root.value > val:
            return self.search(root.left, val)
        if root.right is not None and root.value < val:
            return self.search(root.right, val)
        return root

    def inorder(self, root: Node) -> Generator[Node, None, None]:
        """
        This function takes in a root node and uses a Python Generator to
        recursively yield the left, current, and right nodes.
        It returns a Generator object of yielded nodes.
        """
        if root is None:
            return None
        yield from self.inorder(root.left)
        yield root
        yield from self.inorder(root.right)

    def preorder(self, root: Node) -> Generator[Node, None, None]:
        """
        This function takes in a root node and uses a Python Generator to
        recursively yield the current, left, and right nodes.
        It returns a Generator object of yielded nodes.
        """
        if root is None:
            return None
        yield root
        yield from self.preorder(root.left)
        yield from self.preorder(root.right)

    def postorder(self, root: Node) -> Generator[Node, None, None]:
        """
        This function takes in a root node and uses a Python Generator to
        recursively yield the left, right, and current nodes.
        It returns a Generator object of yielded nodes.
        """
        if root is None:
            return None
        yield from self.postorder(root.left)
        yield from self.postorder(root.right)
        yield root

    def levelorder(self, root: Node) -> Generator[Node, None, None]:
        """
        This function takes in a root node and uses a Python Generator along with
        a queue. It adds/removes tree nodes in the queue by yielding the nodes.
        It returns a Generator object of yielded nodes.
        """
        if root is None:
            return None

        my_queue = queue.SimpleQueue()
        my_queue.put(root)
        while my_queue.qsize() > 0:
            temp = my_queue.get()
            yield temp
            if temp.left is not None:
                my_queue.put(temp.left)
            if temp.right is not None:
                my_queue.put(temp.right)

    def remove(self, root: Node, val: T) -> Node:
        """
        This function takes in a root node and a value. It recursively searches the tree
        for the value and removes it based on the node's children. It updates the height,
        size, and origin as well as re-balances the tree using the re-balance function.
        It returns the removed node.
        """
        if root is None:  # val does not exist
            return None
        if val < root.value:
            root.left = self.remove(root.left, val)
        elif val > root.value:
            root.right = self.remove(root.right, val)
        else:
            if root == self.origin:  # val is the root
                if root.right is None:
                    self.origin = root.left
                    return root
                if root.right is None:
                    self.origin = root.right
                    return root
            if root.left is None:
                right_root = root.right
                root = None
                self.size -= 1
                return self.rebalance(right_root)
            if root.right is None:
                left_root = root.left
                root = None
                self.size -= 1
                return self.rebalance(left_root)
            #  two children
            left_max = self.max(root.left)
            root.value = left_max.value
            root.left = self.remove(root.left, left_max.value)
        root.height = 1 + max(self.height(root.left), self.height(root.right))
        return self.rebalance(root)

####################################################################################################


class AVLWrappedDictionary:
    """
    Implementation of a helper class which will be used as tree node values in the
    NearestNeighborClassifier implementation. Compares objects with keys less than
    1e-6 apart as equal.
    """
    # preallocate storage: see https://stackoverflow.com/questions/472000/usage-of-slots
    __slots__ = ["key", "dictionary"]

    def __init__(self, key: float) -> None:
        """
        Construct a AVLWrappedDictionary with a key to search/sort on and a dictionary to hold data.

        :param key: floating point key to be looked up by.
        """
        self.key = key
        self.dictionary = {}

    def __repr__(self) -> str:
        """
        Represent the AVLWrappedDictionary as a string.

        :return: string representation of the AVLWrappedDictionary.
        """
        return f"key: {self.key}, dict: {self.dictionary}"

    def __str__(self) -> str:
        """
        Represent the AVLWrappedDictionary as a string.

        :return: string representation of the AVLWrappedDictionary.
        """
        return f"key: {self.key}, dict: {self.dictionary}"

    def __eq__(self, other: AVLWrappedDictionary) -> bool:
        """
        Implement == operator to compare 2 AVLWrappedDictionaries by key only.
        Compares objects with keys less than 1e-6 apart as equal.

        :param other: other AVLWrappedDictionary to compare with
        :return: boolean indicating whether keys of AVLWrappedDictionaries are equal
        """
        return abs(self.key - other.key) < 1e-6

    def __lt__(self, other: AVLWrappedDictionary) -> bool:
        """
        Implement < operator to compare 2 AVLWrappedDictionarys by key only.
        Compares objects with keys less than 1e-6 apart as equal.

        :param other: other AVLWrappedDictionary to compare with
        :return: boolean indicating ordering of AVLWrappedDictionaries
        """
        return self.key < other.key and not abs(self.key - other.key) < 1e-6

    def __gt__(self, other: AVLWrappedDictionary) -> bool:
        """
        Implement > operator to compare 2 AVLWrappedDictionaries by key only.
        Compares objects with keys less than 1e-6 apart as equal.

        :param other: other AVLWrappedDictionary to compare with
        :return: boolean indicating ordering of AVLWrappedDictionaries
        """
        return self.key > other.key and not abs(self.key - other.key) < 1e-6


class NearestNeighborClassifier:
    """
    Implementation of a one-dimensional nearest-neighbor classifier with AVL tree lookups.
    Modify only below indicated line.
    """
    # preallocate storage: see https://stackoverflow.com/questions/472000/usage-of-slots
    __slots__ = ["resolution", "tree"]

    def __init__(self, resolution: int) -> None:
        """
        Construct a one-dimensional nearest neighbor classifier with AVL tree lookups.
        Data are assumed to be floating point values in the closed interval [0, 1].

        :param resolution: number of decimal places the data will be rounded to, effectively
                           governing the capacity of the model - for example, with a resolution of
                           1, the classifier could maintain up to 11 nodes, spaced 0.1 apart - with
                           a resolution of 2, the classifier could maintain 101 nodes, spaced 0.01
                           apart, and so on - the maximum number of nodes is bounded by
                           10^(resolution) + 1.
        """
        self.tree = AVLTree()
        self.resolution = resolution

        # pre-construct lookup tree with AVLWrappedDictionary objects storing (key, dictionary)
        # pairs, but which compare with <, >, == on key only
        for i in range(10**resolution + 1):
            w_dict = AVLWrappedDictionary(key=(i/10**resolution))
            self.tree.insert(self.tree.origin, w_dict)

    def __repr__(self) -> str:
        """
        Represent the NearestNeighborClassifier as a string.

        :return: string representation of the NearestNeighborClassifier.
        """
        return f"NNC(resolution={self.resolution}):\n{self.tree}"

    def __str__(self) -> str:
        """
        Represent the NearestNeighborClassifier as a string.

        :return: string representation of the NearestNeighborClassifier.
        """
        return f"NNC(resolution={self.resolution}):\n{self.tree}"

    def fit(self, data: List[Tuple[float, str]]) -> None:
        """
        This function takes in a list of tuples. It iterates through the list and
        searches the tree of the dictionary keys. It then increments the values of
        the dictionary appropriately. It returns nothing.
        """
        for x, y in data:
            key = round(x, self.resolution)
            key_node = self.tree.search(self.tree.origin, AVLWrappedDictionary(key))
            if y in key_node.value.dictionary:
                key_node.value.dictionary[y] += 1
            else:
                key_node.value.dictionary[y] = 1

    def predict(self, x: float, delta: float) -> str:
        """
        This function takes in two floats for the upper and lower bounds, at which
        the dictionary is searched for each node and incremented to a newly created
        dictionary. It returns a string of the maximum values of the new dictionary.
        """
        new_dict = {}
        lower = x - delta
        if lower < 0:
            lower = 0
        upper = x + delta
        if upper > 1:
            upper = 1

        while lower <= upper:
            key = round(lower, self.resolution)
            key_node = self.tree.search(self.tree.origin, AVLWrappedDictionary(key))
            for i in key_node.value.dictionary:
                if i in new_dict:
                    new_dict[i] += key_node.value.dictionary[i]
                else:
                    new_dict[i] = key_node.value.dictionary[i]
            lower += (1 / (10 ** self.resolution))
            lower = round(lower, self.resolution)
        if len(new_dict) == 0:
            return None
        return max(new_dict, key=new_dict.get)
