"""
Rithvik Pennepalli
Coding Challenge 3
CSE 331 Spring 2021
Professor Sebnem Onsay
"""
from typing import List


def finding_best_bot(bots_list: List[int]) -> int:
    """
    This function takes in a list of integers and uses its helper functions to
    determine the index of the list, at which the integers begin to decrease.
    It returns that index.
    """

    def finding_best_bot_helper(start: int, end: int):
        """
        This function is the inner function that takes a start and end index
        of the list and determines where the list begins to decrease.
        It returns that index.
        """
        mid = (start + end) // 2
        if mid == end:
            return end + 1
        if bots_list[mid - 1] <= bots_list[mid] <= bots_list[mid + 1]:
            return finding_best_bot_helper(mid + 1, end)
        if bots_list[mid - 1] <= bots_list[mid] >= bots_list[mid + 1]:
            return mid + 1
        return finding_best_bot_helper(start, mid - 1)

    return finding_best_bot_helper(0, len(bots_list)-1)
