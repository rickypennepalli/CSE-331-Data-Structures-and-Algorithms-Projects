"""
Project 1
CSE 331 S21 (Onsay)
Your Name
DLL.py
"""

from typing import TypeVar  # For use in type hinting
import copy  # crafting function
from Project2.Node import Node       # Import `Node` class

# Type Declarations
T = TypeVar('T')        # generic type
SLL = TypeVar('SLL')    # forward declared


class RecursiveSinglyLinkList:
    """
    Recursive implementation of an SLL
    """

    __slots__ = ['head']

    def __init__(self) -> None:
        """
        Initializes an `SLL`
        :return: None
        """
        self.head = None

    def __repr__(self) -> str:
        """
        Represents an `SLL` as a string
        """
        return self.to_string(self.head)

    def __str__(self) -> str:
        """
        Represents an `SLL` as a string
        """
        return self.to_string(self.head)

    def __eq__(self, other: SLL) -> bool:
        """
        Overloads `==` operator to compare SLLs
        :param other: right hand operand of `==`
        :return: `True` if equal, else `False`
        """
        comp = lambda n1, n2: n1 == n2 and (comp(n1.next, n2.next) if (n1 and n2) else True)
        return comp(self.head, other.head)

# ============ Modify below ============ #

    def to_string(self, curr: Node) -> str:
        """
        This function takes in each node from a linked list and returns the values
        of each node in a string format.
        Time complexity: O(n^2)
        """
        if self.head is None:
            return "None"

        string = str(curr.val)
        if curr.next is not None:
            return string + ' --> ' + self.to_string(curr.next)

        return string

    def length(self, curr: Node) -> int:
        """
        This function takes in each node from a linked list and returns the
        length of the linked list as an int.
        Time complexity: O(n)
        """
        if curr is None:
            return 0

        return 1 + self.length(curr.next)

    def sum_list(self, curr: Node) -> T:
        """
        This function takes in each node from a linked list
        and returns the sum of all values from each node in the list.
        Time complexity: O(n)
        """
        if curr is None:
            return 0

        return curr.val + self.sum_list(curr.next)

    def push(self, value: T) -> None:
        """
        This function takes in a value and uses its inner function
        to append the value as a node to the end of the linked list.
        It returns nothing.
        Time complexity: O(n)
        """
        def push_inner(curr: Node) -> None:
            """
            This function is the inner recursive function that
            takes in the first node of the linked list and appends
            the node to the end of the list. It returns nothing.
            Time complexity: O(n)
            """
            if curr.next is None:
                curr.next = node
                node.next = None
            else:
                push_inner(curr.next)

        node = Node(value)
        if self.head is None:
            self.head = node
        else:
            push_inner(self.head)

    def remove(self, value: T) -> None:
        """
        This function takes in a value and uses its inner function
        to remove the node containing the value from the linked list.
        It returns nothing.
        Time complexity: O(n)
        """
        def remove_inner(curr: Node) -> Node:
            """
            This function is the inner recursive function that takes
            in the first node of the linked list and removes the node
            containing the value. It returns the node to remove.
            Time complexity: O(n)
            """
            if curr is None:
                return 0

            if curr.val == value and self.head == curr:
                if curr.next is None:
                    self.head = None
                    return curr
                self.head = curr.next
                return curr

            if curr.next.val == value:
                curr.next = curr.next.next
                return curr.next
            remove_inner(curr.next)

        if self.head is None:
            return 0
        remove_inner(self.head)

    def remove_all(self, value: T) -> None:
        """
        This function takes in a value and uses its inner function
        to removes all nodes containing the value from the linked list.
        It returns nothing.
        Time complexity: O(n)
        """
        def remove_all_inner(curr):
            """
            This function is the inner recursive function that takes
            in the first node of the linked list and removes all nodes
            containing the value. It returns the node to remove.
            Time complexity: O(n)
            """
            if curr is None:
                return 0
            if curr.val == value and self.head == curr:
                if curr.next is None:
                    self.head = None
                    return curr
                self.head = curr.next

            elif curr.next is not None:
                if curr.next.val == value:
                    curr.next = curr.next.next

            remove_all_inner(curr.next)

        if self.head is None:
            return 0
        remove_all_inner(self.head)

    def search(self, value: T) -> bool:
        """
        This function takes in a value and uses its inner function
        to search for any node containing the value from the linked list.
        It returns True if found.
        Time complexity: O(n)
        """
        def search_inner(curr):
            """
            This function is the inner recursive function that takes
            in the first node of the linked list and searches for any node
            containing the value. It returns True if found.
            Time complexity: O(n)
            """
            if curr is None:
                return False
            if curr.val == value:
                return True
            return search_inner(curr.next)

        return search_inner(self.head)

    def count(self, value: T) -> int:
        """
        This function takes in a value and uses its inner function
        to search for all nodes containing the value from the linked list.
        It returns the total number of nodes containing the value.
        Time complexity: O(n)
        """
        def count_inner(curr):
            """
            This function is the inner recursive function that takes in
            the first node of the linked list and counts for all nodes
            containing the value. It returns that total number.
            Time complexity: O(n)
            """
            if curr is None:
                return 0
            if curr.val == value:
                return 1 + count_inner(curr.next)
            return count_inner(curr.next)

        return count_inner(self.head)

    def reverse(self, curr):
        """
        This function takes in the head of a linked list and reverses
        the order of the list. It returns the new head of the list.
        Time complexity: O(n)
        """
        if curr is None:  # empty list
            return None
        if curr.next is None:  # end of list
            self.head = curr
            return curr

        self.reverse(curr.next)  # loop
        curr.next.next = curr
        curr.next = None
        return curr


def crafting(recipe, pockets):
    """
    This function takes in two linked lists based on animal crossing:
    one as the recipe list and the other as the pocket list. The function
    uses its inner function to search the pocket list for ALL elements
    in the recipe list. It returns True if found. False otherwise.
    Time complexity: O(rp)
    """
    def crafting_remove(pocket, curr: Node):
        """
        This inner functions checks a list of a certain value using the search
        function and removes it using the remove function if found.
        It returns nothing.
        """
        if curr is None:
            return 0
        if pocket.search(curr.val):
            pocket.remove(curr.val)
        if curr.next is not None:
            crafting_remove(pocket, curr.next)

    if recipe.length(recipe.head) == 0:  # empty recipe list
        return False

    copy_pockets = copy.deepcopy(pockets)  # create copy of pocket list
    crafting_remove(copy_pockets, recipe.head)

    new_len = recipe.length(recipe.head) + copy_pockets.length(copy_pockets.head)
    pockets_len = pockets.length(pockets.head)

    if new_len == pockets_len:  # check if recipes + copy_pockets is equal to pockets
        crafting_remove(pockets, recipe.head)
        return True

    copy_pockets.head = pockets.head  # assign head
    return False
