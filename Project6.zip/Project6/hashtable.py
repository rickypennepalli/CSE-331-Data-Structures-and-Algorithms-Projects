"""
Project 6
CSE 331 S21 (Onsay)
Your Name
hashtable.py
"""

from typing import TypeVar, List, Tuple

T = TypeVar("T")
HashNode = TypeVar("HashNode")
HashTable = TypeVar("HashTable")


class HashNode:
    """
    DO NOT EDIT
    """
    __slots__ = ["key", "value", "deleted"]

    def __init__(self, key: str, value: T, deleted: bool = False) -> None:
        self.key = key
        self.value = value
        self.deleted = deleted

    def __str__(self) -> str:
        return f"HashNode({self.key}, {self.value})"

    __repr__ = __str__

    def __eq__(self, other: HashNode) -> bool:
        return self.key == other.key and self.value == other.value

    def __iadd__(self, other: T) -> None:
        self.value += other


class HashTable:
    """
    Hash Table Class
    """
    __slots__ = ['capacity', 'size', 'table', 'prime_index']

    primes = (
        2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83,
        89, 97, 101, 103, 107, 109, 113, 127, 131, 137, 139, 149, 151, 157, 163, 167, 173, 179,
        181, 191, 193, 197, 199, 211, 223, 227, 229, 233, 239, 241, 251, 257, 263, 269, 271, 277,
        281, 283, 293, 307, 311, 313, 317, 331, 337, 347, 349, 353, 359, 367, 373, 379, 383, 389,
        397, 401, 409, 419, 421, 431, 433, 439, 443, 449, 457, 461, 463, 467, 479, 487, 491, 499,
        503, 509, 521, 523, 541, 547, 557, 563, 569, 571, 577, 587, 593, 599, 601, 607, 613, 617,
        619, 631, 641, 643, 647, 653, 659, 661, 673, 677, 683, 691, 701, 709, 719, 727, 733, 739,
        743, 751, 757, 761, 769, 773, 787, 797, 809, 811, 821, 823, 827, 829, 839, 853, 857, 859,
        863, 877, 881, 883, 887, 907, 911, 919, 929, 937, 941, 947, 953, 967, 971, 977, 983, 991,
        997)

    def __init__(self, capacity: int = 8) -> None:
        """
        DO NOT EDIT
        Initializes hash table
        :param capacity: capacity of the hash table
        """
        self.capacity = capacity
        self.size = 0
        self.table = [None] * capacity

        i = 0
        while HashTable.primes[i] <= self.capacity:
            i += 1
        self.prime_index = i - 1

    def __eq__(self, other: HashTable) -> bool:
        """
        DO NOT EDIT
        Equality operator
        :param other: other hash table we are comparing with this one
        :return: bool if equal or not
        """
        if self.capacity != other.capacity or self.size != other.size:
            return False
        for i in range(self.capacity):
            if self.table[i] != other.table[i]:
                return False
        return True

    def __str__(self) -> str:
        """
        DO NOT EDIT
        Represents the table as a string
        :return: string representation of the hash table
        """
        represent = ""
        bin_no = 0
        for item in self.table:
            represent += "[" + str(bin_no) + "]: " + str(item) + '\n'
            bin_no += 1
        return represent

    __repr__ = __str__

    def _hash_1(self, key: str) -> int:
        """
        ---DO NOT EDIT---
        Converts a string x into a bin number for our hash table
        :param key: key to be hashed
        :return: bin number to insert hash item at in our table, None if key is an empty string
        """
        if not key:
            return None
        hashed_value = 0

        for char in key:
            hashed_value = 181 * hashed_value + ord(char)
        return hashed_value % self.capacity

    def _hash_2(self, key: str) -> int:
        """
        ---DO NOT EDIT---
        Converts a string x into a hash
        :param key: key to be hashed
        :return: a hashed value
        """
        if not key:
            return None
        hashed_value = 0

        for char in key:
            hashed_value = 181 * hashed_value + ord(char)

        prime = HashTable.primes[self.prime_index]

        hashed_value = prime - (hashed_value % prime)
        if hashed_value % 2 == 0:
            hashed_value += 1
        return hashed_value

    def __len__(self) -> int:
        """
        This function returns the size of the Hash Table.
        """
        return self.size

    def __setitem__(self, key: str, value: T) -> None:
        """
        This functions takes in a key and a value and sets the pair to be
        inserted into the Hash Table. It returns nothing.
        """
        self._insert(key, value)

    def __getitem__(self, key: str) -> T:
        """
        This function takes in a key and calls the get function to determine and return
        the value associated with the key. It may raise Key Error if bucket is empty.
        """
        bucket = self._get(key)
        if bucket is None:
            raise KeyError
        return bucket.value

    def __delitem__(self, key: str) -> None:
        """
        This function takes in a key and calls the get and delete functions to find, delete, and
        return the hash node associated with the key. It may raise Key Error if bucket is empty.
        """
        bucket = self._get(key)
        if bucket is None:
            raise KeyError
        return self._delete(key)

    def __contains__(self, key: str) -> bool:
        """
        This function takes in a key and calls the get function to determine and return
        ta bool if the node exists in the table.
        """
        bucket = self._get(key)
        if bucket is not None:
            return True
        return False

    def hash(self, key: str, inserting: bool = False) -> int:
        """
        This function takes in a key and a bool to determine the index at which a
        node can be inserted using double hashing. It returns the index as an int.
        """
        original = self._hash_1(key)
        if self.table is None:
            return original

        for i in range(len(self.table)):
            index = (original + (self._hash_2(key) * i)) % self.capacity
            if self.table[index] is None or self.table[index].deleted and inserting:
                break
            if self.table[index].key == key:
                break
        return index

    def _insert(self, key: str, value: T) -> None:
        """
        This function takes in a key and value and inserts it as a hash node into the
        table. If the key is already in the table, it updates the value.
        It returns nothing.
        """
        exists = self._get(key)
        index = self.hash(key)
        node = HashNode(key, value)
        if exists is None:
            self.table[index] = node
            self.size += 1
            self._grow()
        self.table[index] = HashNode(key, value)

    def _get(self, key: str) -> HashNode:
        """
        This function takes in a key and finds the node containing the key in the table.
        It returns the node if found.
        """
        index = self.hash(key)
        if self.table[index] is not None:
            value = self.table[index].value
            node = HashNode(key, value)
            return node

    def _delete(self, key: str) -> None:
        """
        This function takes in a key and deletes its node from the table. It returns nothing.
        """
        index = self.hash(key)
        node = self.table[index]
        if node is not None:
            self.table[index] = HashNode(None, None, deleted=True)
            self.size -= 1

    def _grow(self) -> None:
        """
        This function resizes the table if necessary. It doubles the capacity and sets
        primes. It returns nothing.
        """
        if self.size >= self.capacity // 2:
            #  update capacity
            self.capacity *= 2
            old = self.table
            self.table = self.capacity * [None]
            #  set primes
            i = 0
            while HashTable.primes[i] <= self.capacity:
                i += 1
            self.prime_index = i - 1
            #  update table
            for item in old:
                if item is not None and item.key is not None:
                    index = self.hash(item.key)
                    node = HashNode(item.key, item.value)
                    self.table[index] = node

    def update(self, pairs: List[Tuple[str, T]] = []) -> None:
        """
        This function takes in a list of tuples containing values to be inserted in
        the table. It iterates through the list and inserts the values.
        It returns nothing.
        """
        for key, value in pairs:
            self._insert(key, value)

    def keys(self) -> List[str]:
        """
        This function creates and returns a list of all keys in the table.
        """
        keys_list = []
        for i in self.table:
            if i is not None:
                keys_list.append(i.key)
        return keys_list

    def values(self) -> List[T]:
        """
        This function creates and returns a list of all values in the table.
        """
        values_list = []
        for i in self.table:
            if i is not None:
                values_list.append(i.value)
        return values_list

    def items(self) -> List[Tuple[str, T]]:
        """
        This function creates and returns a list of all items in the table.
        """
        items_list = []
        for i in self.table:
            if i is not None:
                items_list.append((i.key, i.value))
        return items_list

    def clear(self) -> None:
        """
        This function empties the table of all items and returns nothing.
        """
        self.table = [None] * self.capacity
        self.size = 0


class CataData:
    """
    Hash Table Class
    """
    def __init__(self) -> None:
        """
        This function initializes two hash tables to use for the class.
        """
        self.enter_table = HashTable()
        self.exit_table = HashTable()

    def enter(self, idx: str, origin: str, time: int) -> None:
        """
        This function takes in two strings and an int as the name, origin, and
        time a person enters the bus. It inserts the values to a table.
        """
        node = (origin, time)
        self.enter_table[idx] = node

    def exit(self, idx: str, dest: str, time: int) -> None:
        """
        This function takes in two strings and an int as the name, origin, and
        time a person exits the bus. It inserts the values to a table.
        """
        if idx in self.enter_table:
            node = (dest, time)
            self.exit_table[idx] = node

    def get_average(self, origin: str, dest: str) -> float:
        """
        This function takes in an origin and destination and calculates the
        average time it takes for one to travel. It returns the time as a float.
        """
        origins = self.enter_table.values()
        keys = self.enter_table.keys()
        enter_list = []
        for i in range(len(origins)):
            if origins[i][0] == origin:
                name = keys[i]
                time = origins[i][1]
                enter_list.append((name, time))
        exit_list = []
        destinations = self.exit_table.values()
        keys = self.exit_table.keys()
        for i in range(len(destinations)):
            if destinations[i][0] == dest:
                name = keys[i]
                time = destinations[i][1]
                exit_list.append((name, time))
        time = 0.0
        count = 0
        for j in range(len(enter_list)):
            for k in range(len(exit_list)):
                if enter_list[j][0] == exit_list[k][0]:
                    time += exit_list[k][1] - enter_list[j][1]
                    count += 1
        answer = time / count
        return answer
