"""
Project 4
CSE 331 S21 (Onsay)
Rithvik Pennepalli
CircularDeque.py
"""

from __future__ import annotations
from typing import TypeVar, List
# # from re import split as rsplit
# import re

# for more information on type hinting, check out https://docs.python.org/3/library/typing.html
T = TypeVar("T")                                # represents generic type


class CircularDeque:
    """
    Class representation of a Circular Deque
    """

    __slots__ = ['capacity', 'size', 'queue', 'front', 'back']

    def __init__(self, data: List[T] = [], capacity: int = 4):
        """
        Initializes an instance of a CircularDeque
        :param data: starting data to add to the deque, for testing purposes
        :param capacity: amount of space in the deque
        """
        self.capacity: int = capacity
        self.size: int = len(data)

        self.queue: list[T] = [None] * capacity
        self.front: int = None
        self.back: int = None

        for index, value in enumerate(data):
            self.queue[index] = value
            self.front = 0
            self.back = index

    def __str__(self) -> str:
        """
        Provides a string representation of a CircularDeque
        :return: the instance as a string
        """
        if self.size == 0:
            return "CircularDeque <empty>"

        string = f"CircularDeque <{self.queue[self.front]}"
        current_index = self.front + 1 % self.capacity
        while current_index <= self.back:
            string += f", {self.queue[current_index]}"
            current_index = (current_index + 1) % self.capacity
        return string + ">"

    def __repr__(self) -> str:
        """
        Provides a string representation of a CircularDeque
        :return: the instance as a string
        """
        return str(self)

    # ============ Modify below ============ #

    def __len__(self) -> int:
        """
        This function takes in self as the queue list and returns the size
        attribute of it.
        """
        return self.size

    def is_empty(self) -> bool:
        """
        This function takes in self as the queue list and returns true if the size
        attribute of it is empty and false otherwise.
        """
        if self.size == 0:
            return True
        return False

    def front_element(self) -> T:
        """
        This function takes in self as the queue list and returns the front element
        of it using the front attribute.
        """
        if self.size == 0:
            return None
        return self.queue[self.front]

    def back_element(self) -> T:
        """
        This function takes in self as the queue list and returns the back element
        of it using the back attribute.
        """
        if self.size == 0:
            return None
        return self.queue[self.back]

    def front_enqueue(self, value: T) -> None:
        """
        This function takes in self as the queue list and a value to be added to the
        front of it. It adds the element and increases the size while calling the grow
        function. It returns nothing.
        """
        if self.size == 0:
            self.front = self.back = 0
            self.queue[self.front] = value
        else:
            self.front = (self.front - 1) % self.capacity
            self.queue[self.front] = value
        self.size += 1
        self.grow()

    def back_enqueue(self, value: T) -> None:
        """
        This function takes in self as the queue list and a value to be added to the
        back of it. It adds the element and increases the size while calling the grow
        function. It returns nothing.
        """
        if self.size == 0:
            self.front = self.back = 0
            self.queue[self.back] = value
        else:
            self.back = (self.back + 1) % self.capacity
            self.queue[self.back] = value
        self.size += 1
        self.grow()

    def front_dequeue(self) -> T:
        """
        This function takes in self as the queue list. It removes the front element
        and decreases the size while calling the shrink function. It returns the
        removed front element.
        """
        if self.is_empty():
            return None
        answer = self.queue[self.front]
        self.queue[self.front] = None  # help garbage collection
        self.front = (self.front + 1) % self.capacity
        self.size -= 1
        self.shrink()
        return answer

    def back_dequeue(self) -> T:
        """
        This function takes in self as the queue list. It removes the back element
        and decreases the size while calling the shrink function. It returns the
        removed back element.
        """
        if self.is_empty():
            return None
        answer = self.queue[self.back]
        self.queue[self.back] = None  # help garbage collection
        self.back = (self.back - 1) % self.capacity
        self.size -= 1
        self.shrink()
        return answer

    def grow(self) -> None:
        """
        This function takes in self as the queue list. It uses size and capacity
        attributes of it to determine a new capacity if needed. It then doubles
        the capacity, reorganizes the queue accordingly, and returns nothing.
        """
        if self.size == self.capacity:
            old = self.queue
            self.capacity *= 2
            self.queue = [None] * (self.size * 2)
            walk = self.front
            for k in range(self.size):  # only consider existing elements
                self.queue[k] = old[walk]  # intentionally shift indices
                walk = (1 + walk) % len(old)  # use old size as modulus
                self.front = 0
                self.back = k

    def shrink(self) -> None:
        """
        This function takes in self as the queue list. It uses size and capacity
        attributes of it to determine a new capacity if needed. It then halves
        the capacity, reorganizes the queue accordingly, and returns nothing.
        """
        if self.size <= (self.capacity // 4) and (self.capacity // 2) >= 4:
            old = self.queue
            self.capacity //= 2
            self.queue = [None] * self.capacity
            walk = self.front
            for k in range(self.size):  # only consider existing elements
                self.queue[k] = old[walk]  # intentionally shift indices
                walk = (1 + walk) % len(old)  # use old size as modulus
                self.front = 0
                self.back = k


def LetsPassTrains102(infix: str) -> str:
    """
    ops = {'*': 3, '/': 3,  # key: operator, value: precedence
           '+': 2, '-': 2,
           '^': 4,
           '(': 0}  # '(' is lowest bc must be closed by ')'
    """
    empty = infix.split()
    num = ''
    operator = ''
    operators = '+-*/^()'
    for i in empty:
        if i in operators:
            operator += i
        else:
            num += i
        print(i)
    print(num)
    print(operator)
    print(operators)
    print(empty)
    string = ''
    string += num
    string += operator

    return string
