"""
Name
Coding Challenge 2
CSE 331 Spring 2021
Professor Sebnem Onsay
"""
from typing import List, Tuple
from CC2.linked_list import DLLNode, LinkedList


def pokemon_machine(pokemon: LinkedList, orders: List[Tuple]) -> LinkedList:
    """
    This is the main function that holds the inner functions of add, remove, and swap for pokemon in a
    linked list. The function takes in a list of orders and executes them accordingly to amend the linked list.
    """

    def add_pokemon(cur_node: DLLNode, added_pokemon: str) -> None:
        """
        This inner function adds a new node to the linked list that contains the name of the pokemon as its value
        """
        new_node = DLLNode(added_pokemon)
        if cur_node.nxt is None:  # tail
            new_node.prev = cur_node
            cur_node.nxt = new_node
            pokemon.tail = new_node
        else:  # between or head
            next_node = cur_node.nxt
            cur_node.nxt = new_node
            new_node.prev = cur_node
            next_node.prev = new_node
            new_node.nxt = next_node

    def remove_pokemon(cur_node: DLLNode) -> None:
        """
        This inner function removes an existing node from the linked list
        """
        prev_node = cur_node.prev
        next_node = cur_node.nxt
        if cur_node is pokemon.tail:  # tail
            pokemon.tail = prev_node
        if prev_node is not None:
            prev_node.nxt = next_node
        if next_node is not None:
            next_node.prev = prev_node

    def swap_pokemon(first_node: DLLNode, second_node: DLLNode) -> None:
        """
        This inner function swaps the values of two existing nodes in the linked list
        """
        swap = first_node.val
        first_node.val = second_node.val
        second_node.val = swap

    for tup in orders:
        # find the node
        node = pokemon.head
        for i in range(tup[1]):
            node = node.nxt

        if tup[0] == 'add':
            add_pokemon(node, tup[2])
        elif tup[0] == 'remove':
            node = node.nxt
            remove_pokemon(node)
        elif tup[0] == 'swap':
            node = node.nxt
            other_node = pokemon.head.nxt
            for i in range(tup[2]):
                other_node = other_node.nxt
            swap_pokemon(node, other_node)

    return pokemon
